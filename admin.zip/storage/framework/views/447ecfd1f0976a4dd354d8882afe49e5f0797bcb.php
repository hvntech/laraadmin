<ul class="dropdown-menu dropdown-user">
    <?php if(!Auth::user()): ?>
        <li><a href="/auth/login">Login</a></li>
        <li><a href="/auth/register">Signup</a></li>
    <?php else: ?>
        <li><a href="<?php echo e(route('user_account')); ?>"><i class="fa fa-user fa-fw"></i>Hello, <?php echo e(Auth::user()->name); ?> Profile</a>
        </li>
        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
        </li>
        <li><a href="/order"><i class="fa fa-briefcase"></i>  My Order </a></li>
        <li><a href="/cart"><i class="fa fa-shopping-cart"></i>  Cart </a></li>
        <li class="divider"></li>
        <li><a href="<?php echo e(route('authenticated.logout')); ?>"><i class="fa fa-sign-out fa-fw"></i>  Logout </a></li>
    <?php endif; ?>
</ul>