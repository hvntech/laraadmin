<div class="row">
    <div class="col-md-6 col-sm-6 col-xs-6">
        <a href="{{ route('social.redirect', ['provider' => 'google']) }}" class="btn btn-lg waves-effect waves-light btn-block google">Google+</a>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6">
        <a href="{{ route('social.redirect', ['provider' => 'github']) }}" class="btn btn-lg waves-effect waves-light btn-block github">GitHub</a>
    </div>
</div>
